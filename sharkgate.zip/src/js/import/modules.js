import "%modules%/header/header";
import "%modules%/footer/footer"
import "%modules%/navigation/navigation"
import "%modules%/tabs/tabs"
import "%modules%/fill/fill";

