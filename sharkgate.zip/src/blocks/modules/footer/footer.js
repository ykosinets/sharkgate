import $ from 'jquery';

(()=>{
	'use strict';

	console.log('footer');
})();
